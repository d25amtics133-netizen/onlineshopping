using Microsoft.AspNetCore.Mvc;
using OnlineShopping.Services;

namespace OnlineShopping.Controllers
{
    public class ProductController : Controller
    {
        private readonly IProductService _productService;

        public ProductController(
            IProductService productService)
        {
            _productService = productService;
        }

        // Product List
        public async Task<IActionResult> Index()
        {
            var products =
                await _productService.GetProductsAsync();

            // Read customer name from Cookie
            ViewBag.CustomerName =
                Request.Cookies["CustomerName"];

            // Read selected category from Session
            ViewBag.SelectedCategory =
                HttpContext.Session.GetString(
                    "SelectedCategory");

            return View(products);
        }

        // Product Details
        [ResponseCache(
            Duration = 60,
            Location = ResponseCacheLocation.Any,
            NoStore = false)]
        public async Task<IActionResult> Details(int id)
        {
            var product =
                await _productService.GetProductByIdAsync(id);

            if (product == null)
            {
                return NotFound();
            }

            return View(product);
        }

        // Store Customer Name in Cookie
        [HttpPost]
        public IActionResult SetCustomerName(
            string customerName)
        {
            if (!string.IsNullOrWhiteSpace(customerName))
            {
                Response.Cookies.Append(
                    "CustomerName",
                    customerName,
                    new CookieOptions
                    {
                        Expires =
                            DateTimeOffset.UtcNow.AddDays(7),

                        HttpOnly = true
                    });
            }

            return RedirectToAction(nameof(Index));
        }

        // Store Category in Session
        [HttpPost]
        public IActionResult SetCategory(
            string category)
        {
            HttpContext.Session.SetString(
                "SelectedCategory",
                category);

            return RedirectToAction(nameof(Index));
        }

        // Place Order
        [HttpPost]
        public async Task<IActionResult> PlaceOrder(
            int productId,
            int quantity)
        {
            var product =
                await _productService.GetProductByIdAsync(
                    productId);

            if (product == null)
            {
                return NotFound();
            }

            ViewBag.Quantity = quantity;

            return View(
                "OrderConfirmation",
                product);
        }
    }
}