using OnlineShopping.Models;

namespace OnlineShopping.Services
{
    public interface IProductService
    {
        Task<List<Product>> GetProductsAsync();

        Task<Product?> GetProductByIdAsync(int productId);
    }
}