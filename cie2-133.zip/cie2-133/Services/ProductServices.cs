using System.Text.Json;
using Microsoft.Extensions.Caching.Memory;
using OnlineShopping.Models;

namespace OnlineShopping.Services
{
    public class ProductService : IProductService
    {
        private readonly HttpClient _httpClient;
        private readonly IMemoryCache _memoryCache;

        private const string ProductCacheKey = "products";

        public ProductService(
            HttpClient httpClient,
            IMemoryCache memoryCache)
        {
            _httpClient = httpClient;
            _memoryCache = memoryCache;
        }

        public async Task<List<Product>> GetProductsAsync()
        {
            // Check memory cache first
            if (_memoryCache.TryGetValue(
                ProductCacheKey,
                out List<Product>? cachedProducts))
            {
                return cachedProducts!;
            }

            // Call Fake Store API
            var response = await _httpClient.GetAsync(
                "https://fakestoreapi.com/products");

            response.EnsureSuccessStatusCode();

            var json =
                await response.Content.ReadAsStringAsync();

            // Convert JSON to objects
            var apiProducts =
                JsonSerializer.Deserialize<List<FakeStoreProduct>>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

            // Convert API data to our Product model
            var products = apiProducts?
                .Select(p => new Product
                {
                    ProductId = p.Id,
                    ProductName = p.Title,
                    Category = p.Category,
                    Price = p.Price,

                    // 10% sample discount
                    DiscountPercentage = 10
                })
                .ToList()
                ?? new List<Product>();

            // Cache product list for 10 minutes
            var cacheOptions =
                new MemoryCacheEntryOptions
                {
                    AbsoluteExpirationRelativeToNow =
                        TimeSpan.FromMinutes(10)
                };

            _memoryCache.Set(
                ProductCacheKey,
                products,
                cacheOptions);

            return products;
        }

        public async Task<Product?> GetProductByIdAsync(
            int productId)
        {
            var products =
                await GetProductsAsync();

            return products.FirstOrDefault(
                p => p.ProductId == productId);
        }
    }
}