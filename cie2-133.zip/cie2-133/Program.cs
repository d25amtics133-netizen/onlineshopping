using OnlineShopping.Services;

var builder = WebApplication.CreateBuilder(args);

// Add MVC
builder.Services.AddControllersWithViews();

// Enable IMemoryCache
builder.Services.AddMemoryCache();

// Register HttpClient and ProductService
builder.Services.AddHttpClient<
    IProductService,
    ProductService>();

// Enable Session
builder.Services.AddDistributedMemoryCache();

builder.Services.AddSession(options =>
{
    options.IdleTimeout =
        TimeSpan.FromMinutes(30);

    options.Cookie.HttpOnly = true;

    options.Cookie.IsEssential = true;
});

// Enable Response Caching
builder.Services.AddResponseCaching();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");

    app.UseHsts();
}

app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

// Response caching middleware
app.UseResponseCaching();

// Session middleware
app.UseSession();

app.UseAuthorization();

// Product page as default page
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Product}/{action=Index}/{id?}");

app.Run();